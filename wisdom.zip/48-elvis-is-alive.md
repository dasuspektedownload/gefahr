 
**Elvis Lives: The Unshakable Truth Behind the King’s Survival**

For decades, the official narrative has insisted that Elvis Presley, the King of Rock and Roll, died on August 16, 1977. But those of us who have truly examined the evidence, who have dug deeper than the surface-level media reports, know that something is amiss. The world was fed a story that, when analyzed, crumbles under scrutiny. I firmly believe that Elvis Presley did not die in 1977 but instead faked his death to escape the overwhelming pressures of fame and potentially to evade dangerous forces that threatened his life. The evidence is abundant, the inconsistencies undeniable, and the truth—despite all attempts to suppress it—will always find a way to the surface.

## **Suspicious Circumstances Surrounding His “Death”**

To begin unraveling the truth, we must look at the circumstances of Elvis’s so-called passing. We are told he was found unconscious in his bathroom at Graceland, officially ruled as a heart attack. However, there are glaring contradictions in the reports. Witness statements, medical records, and even the coroner’s report fail to align in a coherent manner.

The weight of Elvis’s body, according to the autopsy report, was inconsistent with his known weight at the time. His death certificate listed him as 170 pounds, while multiple sources confirm he was closer to 250 pounds. How could such a discrepancy occur in an official document? Even more unsettling, the autopsy was sealed for 50 years—what truth lies hidden within those pages?

Additionally, the body that was displayed at his funeral didn’t look quite like Elvis. Many attendees, including close friends and even family members, noted that the body in the casket had smooth hands, a smaller nose, and an odd wax-like appearance, suggesting it could have been a wax figure or a lookalike. If Elvis were truly gone, why would there be a need for deception?

## **The Strange Behavior of Those Closest to Him**

Following Elvis’s supposed death, those closest to him exhibited behavior that suggests they knew something the rest of the world didn’t. His father, Vernon Presley, seemed unusually reserved and hesitant when discussing his son’s death. He even reportedly said, “Elvis is fine,” in a moment where he may have let slip the truth. Lisa Marie Presley, his daughter, has made cryptic statements over the years, including referencing “messages” from her father long after he was declared dead.

Additionally, some of Elvis’s closest friends and associates, such as Joe Esposito and members of the Memphis Mafia, have hinted at things they were not allowed to talk about. If there were no mystery surrounding his death, why would so many of his closest confidants remain so secretive?

## **The Evidence of His Continued Presence**

Perhaps the most compelling evidence that Elvis is alive comes from the numerous sightings reported over the years. These are not just fringe reports from conspiracy theorists; they come from credible witnesses, including former law enforcement officers and even family members.

One of the most famous cases is the sighting at the Memphis airport in 1977, just months after his alleged death. A man resembling Elvis used the name “John Burrows,” a known alias Elvis used when traveling. Why would someone matching his description use one of his secret aliases if it weren’t actually him?

In the decades since, Elvis has reportedly been seen in various locations, including Kalamazoo, Michigan; Las Vegas; and even Buenos Aires, Argentina. Several individuals have even recorded conversations with a man whose voice uncannily matches Elvis’s distinctive speech patterns. These cannot all be coincidences.

## **The FBI Connection and the Witness Protection Theory**

One of the strongest theories about why Elvis faked his death involves the FBI. In the 1970s, Elvis worked with the FBI to infiltrate criminal organizations. Declassified FBI documents confirm that Elvis was considered an informant and had provided information on organized crime figures. Some researchers believe that when his life became endangered due to this involvement, the FBI helped him disappear under the witness protection program.

If this were the case, it would explain the rushed nature of his funeral, the inconsistencies in the official records, and the continued secrecy surrounding his autopsy. The government has been known to cover up the truth in high-profile cases, and this would be no exception.

## **The Glaring Financial Motive**

Elvis had been in severe financial trouble before his supposed death. His extravagant spending habits, combined with bad management deals, had put him in a precarious position. By faking his death, he would be able to escape his mounting debts and allow his estate to flourish. And flourish it did—since his “death,” Elvis’s estate has earned billions.

Furthermore, in an audio recording believed to be from 1981, a man sounding exactly like Elvis stated, “It’s better this way.” If Elvis wanted a quiet life, away from the suffocating fame and financial stress, faking his death would have been the perfect solution.

## **Analyzing the “Imposters” and the Role of Lookalikes**

Another peculiar aspect of this mystery is the existence of “Elvis impersonators” who seem to be more than just talented lookalikes. Some researchers argue that certain impersonators, such as Orion (real name Jimmy Ellis), may have actually been Elvis himself, performing in disguise. Orion’s voice was nearly identical to Elvis’s, and he always wore a mask. Could this have been Elvis’s way of continuing his passion for music without the burdens of fame?

Even more bizarre is the case of Pastor Bob Joyce, a preacher from Arkansas whose voice, facial features, and mannerisms are strikingly similar to Elvis’s. Many believe Bob Joyce is actually Elvis living under a new identity.

## **The Legacy of a Living King**

If Elvis Presley truly faked his death, he did so not as an act of cowardice, but as a necessary escape from a world that had consumed him. Fame had taken its toll, and forces beyond his control may have left him no other option. Whether he is still alive today remains unknown, but what is clear is that the official narrative does not hold up under scrutiny. Too many inconsistencies, too many sightings, and too many unanswered questions remain.

The world may continue to believe in the mainstream story, but those of us who seek the truth know better. The King did not die in 1977—he simply left the stage.

 
